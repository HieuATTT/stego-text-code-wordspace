import os

def text_to_binary(text):
    """Chuyển văn bản thành chuỗi bit nhị phân."""
    binary = ''
    for char in text:
        binary += format(ord(char), '08b')
    return binary

def read_file(file_path):
    """Đọc nội dung file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read().strip()
    except FileNotFoundError:
        print(f"Error: File {file_path} not found.")
        return None

def write_file(file_path, content):
    """Ghi nội dung vào file."""
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

def encode_message(original_text, secret_binary):
    """Mã hóa chuỗi bit vào văn bản gốc bằng khoảng trắng tại các từ vị trí chẵn."""
    # Tách văn bản gốc thành danh sách từ
    words = [word for word in original_text.split() if word]
    if len(words) < 2:
        print("Error: Original text must have at least 2 words.")
        return original_text

    # Đếm số từ ở vị trí chẵn (w2, w4,...)
    encodable_positions = (len(words) + 1) // 2
    if encodable_positions < len(secret_binary):
        print(f"Error: Only {encodable_positions} even-positioned words available, need {len(secret_binary)}.")
        return original_text

    encoded_text = []
    bit_index = 0

    for i in range(len(words)):
        current_word = words[i]
        word_position = i + 1  # w1, w2,...

        if word_position % 2 == 0 and bit_index < len(secret_binary):
            # Giấu tin tại w2, w4,...
            bit = secret_binary[bit_index]
            if bit == '0':
                # Bit 0: từ + 2 khoảng trắng sau
                encoded_text.append(current_word + '  ')
                bit_index += 1
            elif bit == '1':
                # Bit 1: 1 khoảng trắng trước + từ + 1 khoảng trắng sau
                encoded_text.append(' ' + current_word + ' ')
                bit_index += 1
        else:
            # Null hoặc từ cuối
            if i < len(words) - 1:
                encoded_text.append(current_word + ' ')
            else:
                encoded_text.append(current_word)

    result = ''.join(encoded_text).lstrip()
    return result

def main():
    # Đọc file input
    input_text = read_file('input.txt')
    secret_text = read_file('secret.txt')
    
    if input_text is None or secret_text is None:
        return

    # Chuyển thông điệp bí mật thành nhị phân
    secret_binary = text_to_binary(secret_text)
    
    # Ghi chuỗi bit vào file binary_secret.txt
    write_file('binary_secret.txt', secret_binary)
    
    # Mã hóa thông điệp vào văn bản gốc
    encoded_text = encode_message(input_text, secret_binary)
    
    # Ghi văn bản đã mã hóa vào file encoded.txt
    write_file('encoded.txt', encoded_text)
    
    # In thông báo thành công
    print("Encoding completed successfully!")
    print(f"Binary secret saved to binary_secret.txt")
    print(f"Encoded text saved to encoded.txt")

if __name__ == "__main__":
    main()
