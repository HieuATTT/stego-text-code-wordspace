import os

def read_file(file_path):
    """Đọc nội dung file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read().strip()
    except FileNotFoundError:
        print(f"Error: File {file_path} not found.")
        return None

def write_file(file_path, content):
    """Ghi nội dung vào file."""
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

def binary_to_text(binary):
    """Chuyển chuỗi bit nhị phân thành văn bản."""
    text = ''
    binary = binary[:len(binary) - (len(binary) % 8)]
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        if len(byte) == 8:
            char_code = int(byte, 2)
            text += chr(char_code)
    return text

def decode_message(encoded_text):
    """Trích xuất chuỗi bit từ văn bản mã hóa."""
    words = [word for word in encoded_text.split() if word]
    if len(words) < 2:
        print("Error: Encoded text must have at least 2 words.")
        return ''

    bits = []
    current_pos = 0  # Vị trí hiện tại trong chuỗi gốc

    for i in range(1, len(words), 2):
        if i >= len(words) - 1:
            break
        current_word = words[i]
        
        # Tìm từ hiện tại trong chuỗi từ vị trí hiện tại
        start_idx = encoded_text.find(current_word, current_pos)
        if start_idx == -1:
            break
        
        # Đếm khoảng trắng trước
        spaces_before = 0
        before_idx = start_idx - 1
        while before_idx >= 0 and encoded_text[before_idx] == ' ':
            spaces_before += 1
            before_idx -= 1
        
        # Đếm khoảng trắng sau
        word_end = start_idx + len(current_word)
        spaces_after = 0
        after_idx = word_end
        while after_idx < len(encoded_text) and encoded_text[after_idx] == ' ':
            spaces_after += 1
            after_idx += 1
        
        # Cập nhật vị trí cho từ tiếp theo
        current_pos = after_idx
        
        # Kiểm tra quy tắc
        if spaces_before == 1 and spaces_after == 2:
            bits.append('0')
        elif spaces_before == 2 and spaces_after == 1:
            bits.append('1')
        # Bỏ qua nếu không khớp mẫu
    
    decoded_binary = ''.join(bits)
    if not decoded_binary:
        print("Error: No bits decoded from encoded text.")
    return decoded_binary

def main():
    # Đọc file encoded.txt
    encoded_text = read_file('encoded.txt')
    if encoded_text is None:
        return

    # Trích xuất chuỗi bit
    decoded_binary = decode_message(encoded_text)
    if not decoded_binary:
        return
    
    # Lưu chuỗi bit vào decoded_binary.txt
    write_file('decoded_binary.txt', decoded_binary)
    
    # Chuyển chuỗi bit thành văn bản
    decoded_text = binary_to_text(decoded_binary)
    
    # Lưu văn bản vào output.txt
    write_file('output.txt', decoded_text)
    
    print("Decoding completed successfully!")
    print(f"Decoded binary saved to decoded_binary.txt")
    print(f"Decoded text saved to output.txt")

if __name__ == "__main__":
    main()
